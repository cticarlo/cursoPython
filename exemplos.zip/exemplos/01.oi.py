# -*- coding: utf-8 -*-
"""
Created on Thu Jun  2 09:41:39 2016

@author: carlos
"""


resposta = 42

nada = None

nada = 0.0

msg = u"Hi, mundo!!!"


print u"Ola, mundo"
print msg
#reraw_input("")

