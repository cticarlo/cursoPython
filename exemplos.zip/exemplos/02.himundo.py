# -*- coding: utf-8 -*-
"""
Created on Tue Jun 13 15:30:51 2017

@author: carlos
"""

nome = raw_input("Qual é a sua graça? ")

print "\nHi, {}!!!\n".format(nome)

print 'Hi, ',
print nome,
print "!!!\n"
