# -*- coding: utf-8 -*-
"""
Created on Thu Jun  2 10:17:17 2016

@author: carlos
"""

a = input (u"Entre com o dividendo: ")
b = input (u"Entre com o divisor: ")


resultado = u"A divisão de {} por {} é {}".format(a, b, a/b)

print resultado
