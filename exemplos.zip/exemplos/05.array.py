# -*- coding: utf-8 -*-
"""
Created on Sun Aug 13 18:59:17 2017

@author: carlos
"""
import numpy as np

a=np.array([0,1,2])
b=np.array([3,4,5])
c=a+b
print c